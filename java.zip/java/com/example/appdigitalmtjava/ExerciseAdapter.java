package com.example.appdigitalmtjava;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class ExerciseAdapter extends RecyclerView.Adapter<ExerciseAdapter.ExerciseViewHolder> {

    private List<Exercise> exerciseList;
    private OnExerciseCheckedChangeListener onExerciseCheckedChangeListener;

    public interface OnExerciseCheckedChangeListener {
        void onExerciseCheckedChange();
    }

    public ExerciseAdapter(List<Exercise> exerciseList, OnExerciseCheckedChangeListener listener) {
        this.exerciseList = exerciseList;
        this.onExerciseCheckedChangeListener = listener;
    }

    @NonNull
    @Override
    public ExerciseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.exercise_item, parent, false);
        return new ExerciseViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ExerciseViewHolder holder, int position) {
        Exercise exercise = exerciseList.get(position);
        holder.exerciseTitle.setText(exercise.getTitle());
        holder.exerciseDescription.setText(exercise.getDescription());
        holder.exerciseCheckBox.setChecked(exercise.isCompleted());

        holder.exerciseCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            exercise.setCompleted(isChecked);
            if (onExerciseCheckedChangeListener != null) {
                onExerciseCheckedChangeListener.onExerciseCheckedChange();
            }
        });
    }

    @Override
    public int getItemCount() {
        return exerciseList.size();
    }

    public static class ExerciseViewHolder extends RecyclerView.ViewHolder {
        TextView exerciseTitle;
        TextView exerciseDescription;
        CheckBox exerciseCheckBox;

        public ExerciseViewHolder(@NonNull View itemView) {
            super(itemView);
            exerciseTitle = itemView.findViewById(R.id.exerciseTitle);
            exerciseDescription = itemView.findViewById(R.id.exerciseDescription);
            exerciseCheckBox = itemView.findViewById(R.id.exerciseCheckBox);
        }
    }
}
