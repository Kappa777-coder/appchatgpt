package com.example.appdigitalmtjava;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class RecipesAdapter extends RecyclerView.Adapter<RecipesAdapter.RecipeViewHolder> {

    private List<Recipe> recipeList;

    public RecipesAdapter(List<Recipe> recipeList) {
        this.recipeList = recipeList;
    }

    @NonNull
    @Override
    public RecipeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recipe_list_item, parent, false);
        return new RecipeViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecipeViewHolder holder, int position) {
        Recipe recipe = recipeList.get(position);
        holder.recipeTitleTextView.setText(recipe.getTitle());
        holder.recipeDescriptionTextView.setText(recipe.getDescription());
        holder.recipeImageView.setImageResource(recipe.getImageResId());
        holder.bind(recipe);
    }

    @Override
    public int getItemCount() {
        return recipeList.size();
    }

    public class RecipeViewHolder extends RecyclerView.ViewHolder {
        TextView recipeTitleTextView;
        TextView recipeDescriptionTextView;
        ImageView recipeImageView;

        public RecipeViewHolder(@NonNull View itemView) {
            super(itemView);
            recipeTitleTextView = itemView.findViewById(R.id.recipeTitle);
            recipeDescriptionTextView = itemView.findViewById(R.id.recipeDescription);
            recipeImageView = itemView.findViewById(R.id.recipeImage);
        }

        public void bind(final Recipe recipe) {
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Navegar para o fragmento de detalhes da receita
                    RecipeDetailFragment recipeDetailFragment = new RecipeDetailFragment();
                    Bundle bundle = new Bundle();
                    bundle.putInt("IMAGE_RES_ID", recipe.getImageResId());
                    bundle.putString("TITLE", recipe.getTitle());

                    if (recipe.getIngredients() != null) {
                        bundle.putString("INGREDIENTS", recipe.getIngredients());
                    } else {
                        bundle.putString("BASE", recipe.getBase());
                        bundle.putString("RECHEIO", recipe.getRecheio());
                        bundle.putString("TEMPERO", recipe.getTempero());
                    }

                    recipeDetailFragment.setArguments(bundle);

                    FragmentManager fragmentManager = ((FragmentActivity) itemView.getContext()).getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.fragment_container, recipeDetailFragment);
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();
                }
            });
        }
    }
}
