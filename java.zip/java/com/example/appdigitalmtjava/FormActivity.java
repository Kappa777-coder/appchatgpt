package com.example.appdigitalmtjava;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class FormActivity extends AppCompatActivity {

    EditText nameText, weightText, waistText, ageText;
    RadioGroup genderGroup;
    Button calculateButton, submitButton;
    TextView waterResultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);

        nameText = findViewById(R.id.nameText);
        weightText = findViewById(R.id.weightText);
        waistText = findViewById(R.id.waistText);
        ageText = findViewById(R.id.ageText);
        genderGroup = findViewById(R.id.genderGroup);
        calculateButton = findViewById(R.id.calculateButton);
        submitButton = findViewById(R.id.submitButton);
        waterResultText = findViewById(R.id.waterResultText);

        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String weightStr = weightText.getText().toString();

                if (weightStr.isEmpty()) {
                    Toast.makeText(FormActivity.this, "Por favor, insira seu peso.", Toast.LENGTH_SHORT).show();
                } else {
                    double weight = Double.parseDouble(weightStr);
                    double waterIntake = weight * 0.03;
                    waterResultText.setText("Quantidade de água recomendada por dia: " + String.format("%.2f", waterIntake) + " litros");
                    waterResultText.setVisibility(View.VISIBLE);
                }
            }
        });

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameText.getText().toString();
                String weight = weightText.getText().toString();
                String waist = waistText.getText().toString();
                String age = ageText.getText().toString();
                int selectedGenderId = genderGroup.getCheckedRadioButtonId();
                RadioButton selectedGenderButton = findViewById(selectedGenderId);
                String gender = selectedGenderButton == null ? "" : selectedGenderButton.getText().toString();
                String waterIntake = waterResultText.getText().toString();

                if (name.isEmpty() || weight.isEmpty() || waist.isEmpty() || age.isEmpty() || gender.isEmpty() || waterIntake.isEmpty()) {
                    Toast.makeText(FormActivity.this, "Por favor, preencha todos os campos.", Toast.LENGTH_SHORT).show();
                } else {
                    // Salvar estado indicando que o formulário foi preenchido
                    SharedPreferences sharedPreferences = getSharedPreferences("appPreferences", MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putBoolean("formFilled", true);
                    editor.putString("userName", name); // Salvar o nome do usuário
                    editor.putString("userWeight", weight); // Salvar o peso do usuário
                    editor.putString("userWaist", waist); // Salvar a medida da cintura do usuário
                    editor.putString("userAge", age); // Salvar a idade do usuário
                    editor.putString("userGender", gender); // Salvar o gênero do usuário
                    editor.putString("waterIntake", waterIntake); // Salvar a quantidade de água
                    editor.apply();

                    // Navegar para a HomeActivity e passar o nome do usuário
                    Intent intent = new Intent(FormActivity.this, HomeActivity.class);
                    intent.putExtra("USER_NAME", name);
                    // Adicionar flags para limpar a pilha de atividades
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish(); // Finaliza a FormActivity
                }
            }
        });
    }
}
