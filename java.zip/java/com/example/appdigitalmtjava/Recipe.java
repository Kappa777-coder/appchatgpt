package com.example.appdigitalmtjava;

public class Recipe {
    private String title;
    private String description;
    private int imageResId;
    private String ingredients; // Para sumos
    private String base;        // Para marmitas
    private String recheio;     // Para marmitas
    private String tempero;     // Para marmitas

    public Recipe(String title, String description, int imageResId, String ingredients) {
        this.title = title;
        this.description = description;
        this.imageResId = imageResId;
        this.ingredients = ingredients;
    }

    public Recipe(String title, String description, int imageResId, String base, String recheio, String tempero) {
        this.title = title;
        this.description = description;
        this.imageResId = imageResId;
        this.base = base;
        this.recheio = recheio;
        this.tempero = tempero;
    }

    // Getters e setters
    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public int getImageResId() {
        return imageResId;
    }

    public String getIngredients() {
        return ingredients;
    }

    public String getBase() {
        return base;
    }

    public String getRecheio() {
        return recheio;
    }

    public String getTempero() {
        return tempero;
    }
}
