package com.example.appdigitalmtjava;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences sharedPreferences = getSharedPreferences("appPreferences", MODE_PRIVATE);
        boolean formFilled = sharedPreferences.getBoolean("formFilled", false);

        if (formFilled) {
            // Redirecionar para HomeActivity
            String userName = sharedPreferences.getString("userName", "Usuário");
            Intent intent = new Intent(SplashActivity.this, HomeActivity.class);
            intent.putExtra("USER_NAME", userName);
            startActivity(intent);
        } else {
            // Redirecionar para LoginActivity
            Intent intent = new Intent(SplashActivity.this, MainActivity.class);
            startActivity(intent);
        }

        finish(); // Finaliza a SplashActivity
    }
}
