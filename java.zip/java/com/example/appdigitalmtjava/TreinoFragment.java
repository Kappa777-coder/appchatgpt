package com.example.appdigitalmtjava;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.GridLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class TreinoFragment extends Fragment {

    private RecyclerView exercisesRecyclerView;
    private ExerciseAdapter exerciseAdapter;
    private List<Exercise> exerciseList;
    private int currentDay = 1;

    private TextView dayTitleTextView;
    private GridLayout calendarGrid;
    private SharedPreferences sharedPreferences;

    public TreinoFragment() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_treino, container, false);

        sharedPreferences = getActivity().getSharedPreferences("ExercisePrefs", Context.MODE_PRIVATE);

        exercisesRecyclerView = view.findViewById(R.id.exercisesRecyclerView);
        exercisesRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        dayTitleTextView = view.findViewById(R.id.dayTitleTextView);
        calendarGrid = view.findViewById(R.id.calendarGrid);

        // Inicializar lista de exercícios
        exerciseList = new ArrayList<>();
        setupCalendar();

        exerciseAdapter = new ExerciseAdapter(exerciseList, new ExerciseAdapter.OnExerciseCheckedChangeListener() {
            @Override
            public void onExerciseCheckedChange() {
                updateArrowIndicator();
                saveExerciseStates();
                updateDayButtonColors(); // Atualizar as cores dos botões dos dias
            }
        });
        exercisesRecyclerView.setAdapter(exerciseAdapter);

        // Carregar os exercícios para o dia atual (Dia 1)
        loadExercisesForDay(currentDay);

        return view;
    }

    private void setupCalendar() {
        LayoutInflater inflater = LayoutInflater.from(getContext());
        for (int day = 1; day <= 15; day++) {
            View dayView = inflater.inflate(R.layout.item_calendar_button, calendarGrid, false);
            TextView dayNumber = dayView.findViewById(R.id.dayNumber);
            dayNumber.setText(String.valueOf(day));

            dayView.setTag(day);
            dayView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int selectedDay = (int) v.getTag();
                    if (selectedDay == 1 || isDayCompleted(selectedDay - 1)) {
                        currentDay = selectedDay;
                        updateDayTitle();
                        animateExerciseChange();
                    }
                }
            });
            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.width = 0;
            params.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            params.rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            params.setMargins(8, 8, 8, 8); // Aumentar a margem para espaçamento adequado
            dayView.setLayoutParams(params);
            calendarGrid.addView(dayView);
        }
    }

    private boolean isDayCompleted(int day) {
        for (int i = 0; i < 3; i++) {
            if (!sharedPreferences.getBoolean("day_" + day + "_exercise_" + i, false)) {
                return false;
            }
        }
        return true;
    }

    private void loadExercisesForDay(int day) {
        exerciseList.clear();
        addExercisesForDay(day);
        loadExerciseStates();
        exerciseAdapter.notifyDataSetChanged(); // Notificar o adapter sobre as mudanças
    }

    private void addExercisesForDay(int day) {
        switch (day) {
            case 1:
                exerciseList.add(new Exercise("00:00-08:00", "Jejum"));
                exerciseList.add(new Exercise("08:00-16:00", "Complete o jejum de 14h, Tomar sumo verde, Almoço dentro das refeições sugeridas"));
                exerciseList.add(new Exercise("16:00-24:00", "Jantar dentro das refeições sugeridas até as 20h, Início do jejum de 16h"));
                break;
            case 2:
                exerciseList.add(new Exercise("00:00-08:00", "Jejum"));
                exerciseList.add(new Exercise("08:00-16:00", "Complete o jejum de 16h, Quebrar jejum com sumo verde, Almoço dentro das refeições sugeridas"));
                exerciseList.add(new Exercise("16:00-24:00", "Jantar dentro das refeições sugeridas, Iniciar jejum de 18h"));
                break;
            case 3:
                exerciseList.add(new Exercise("00:00-08:00", "Jejum"));
                exerciseList.add(new Exercise("08:00-16:00", "Complete o jejum de 18h, Quebrar jejum com sumo verde, Almoço dentro das refeições sugeridas"));
                exerciseList.add(new Exercise("16:00-24:00", "Jantar dentro das refeições sugeridas, Iniciar jejum de 20h"));
                break;
            case 4:
                exerciseList.add(new Exercise("00:00-08:00", "Jejum"));
                exerciseList.add(new Exercise("08:00-16:00", "Jejum"));
                exerciseList.add(new Exercise("16:00-24:00", "Completar jejum de 20h, quebrar jejum com sumo verde, Jantar dentro das refeições sugeridas até as 20h, início do jejum de 24h (OMAD)"));
                break;
            case 5:
                exerciseList.add(new Exercise("00:00-08:00", "Jejum"));
                exerciseList.add(new Exercise("08:00-16:00", "Jejum"));
                exerciseList.add(new Exercise("16:00-24:00", "Completar jejum de 24h, quebrar jejum com sumo verde, Jantar dentro das refeições sugeridas, início do jejum de 14h"));
                break;
            case 6:
                exerciseList.add(new Exercise("00:00-08:00", "Jejum"));
                exerciseList.add(new Exercise("08:00-16:00", "Complete o jejum de 14h, Tomar sumo verde, Almoço dentro das refeições sugeridas"));
                exerciseList.add(new Exercise("16:00-24:00", "Jantar dentro das refeições sugeridas até as 20h, Início do jejum de 16h"));
                break;
            case 7:
                exerciseList.add(new Exercise("00:00-08:00", "Jejum"));
                exerciseList.add(new Exercise("08:00-16:00", "Complete o jejum de 16h, Quebrar jejum com sumo verde, Almoço dentro das refeições sugeridas"));
                exerciseList.add(new Exercise("16:00-24:00", "Jantar dentro das refeições sugeridas, Iniciar jejum de 18h"));
                break;
            case 8:
                exerciseList.add(new Exercise("00:00-08:00", "Jejum"));
                exerciseList.add(new Exercise("08:00-16:00", "Complete o jejum de 18h, Quebrar jejum com sumo verde, Almoço dentro das refeições sugeridas"));
                exerciseList.add(new Exercise("16:00-24:00", "Jantar dentro das refeições sugeridas, Iniciar jejum de 20h"));
                break;
            case 9:
                exerciseList.add(new Exercise("00:00-08:00", "Jejum"));
                exerciseList.add(new Exercise("08:00-16:00", "Jejum"));
                exerciseList.add(new Exercise("16:00-24:00", "Completar jejum de 20h, quebrar jejum com sumo verde, Jantar dentro das refeições sugeridas até as 20h, início do jejum de 24h (OMAD)"));
                break;
            case 10:
                exerciseList.add(new Exercise("00:00-08:00", "Jejum"));
                exerciseList.add(new Exercise("08:00-16:00", "Jejum"));
                exerciseList.add(new Exercise("16:00-24:00", "Completar jejum de 24h, quebrar jejum com sumo verde, Jantar dentro das refeições sugeridas, início do jejum de 14h"));
                break;
            case 11:
                exerciseList.add(new Exercise("00:00-08:00", "Jejum"));
                exerciseList.add(new Exercise("08:00-16:00", "Complete o jejum de 14h, Tomar sumo verde, Almoço dentro das refeições sugeridas"));
                exerciseList.add(new Exercise("16:00-24:00", "Jantar dentro das refeições sugeridas até as 20h, Início do jejum de 16h"));
                break;
            case 12:
                exerciseList.add(new Exercise("00:00-08:00", "Jejum"));
                exerciseList.add(new Exercise("08:00-16:00", "Complete o jejum de 16h, Quebrar jejum com sumo verde, Almoço dentro das refeições sugeridas"));
                exerciseList.add(new Exercise("16:00-24:00", "Jantar dentro das refeições sugeridas, Iniciar jejum de 18h"));
                break;
            case 13:
                exerciseList.add(new Exercise("00:00-08:00", "Jejum"));
                exerciseList.add(new Exercise("08:00-16:00", "Complete o jejum de 18h, Quebrar jejum com sumo verde, Almoço dentro das refeições sugeridas"));
                exerciseList.add(new Exercise("16:00-24:00", "Jantar dentro das refeições sugeridas, Iniciar jejum de 20h"));
                break;
            case 14:
                exerciseList.add(new Exercise("00:00-08:00", "Jejum"));
                exerciseList.add(new Exercise("08:00-16:00", "Jejum"));
                exerciseList.add(new Exercise("16:00-24:00", "Completar jejum de 20h, quebrar jejum com sumo verde, Jantar dentro das refeições sugeridas até as 20h, início do jejum de 24h (OMAD)"));
                break;
            case 15:
                exerciseList.add(new Exercise("00:00-08:00", "Jejum"));
                exerciseList.add(new Exercise("08:00-16:00", "Jejum"));
                exerciseList.add(new Exercise("16:00-24:00", "Completar jejum de 24h, quebrar jejum com sumo verde, Jantar dentro das refeições sugeridas, início do jejum de 14h"));
                break;
            default:
                exerciseList.add(new Exercise("00:00-08:00", "Descrição do exercício 1 para o dia " + day));
                exerciseList.add(new Exercise("08:00-16:00", "Descrição do exercício 2 para o dia " + day));
                exerciseList.add(new Exercise("16:00-24:00", "Descrição do exercício 3 para o dia " + day));
                break;
        }
    }


    private void updateDayTitle() {
        dayTitleTextView.setText("Dia " + currentDay);
    }

    private void updateArrowIndicator() {
        boolean allExercisesCompleted = true;
        for (Exercise exercise : exerciseList) {
            if (!exercise.isCompleted()) {
                allExercisesCompleted = false;
                break;
            }
        }
    }

    private void saveExerciseStates() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        for (int i = 0; i < exerciseList.size(); i++) {
            editor.putBoolean("day_" + currentDay + "_exercise_" + i, exerciseList.get(i).isCompleted());
        }
        editor.apply();
    }

    private void loadExerciseStates() {
        for (int i = 0; i < exerciseList.size(); i++) {
            boolean completed = sharedPreferences.getBoolean("day_" + currentDay + "_exercise_" + i, false);
            exerciseList.get(i).setCompleted(completed);
        }
    }

    private void animateExerciseChange() {
        Animation slideOut = AnimationUtils.loadAnimation(getContext(), R.anim.slide_out_left);

        exercisesRecyclerView.startAnimation(slideOut);
        slideOut.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {}

            @Override
            public void onAnimationEnd(Animation animation) {
                loadExercisesForDay(currentDay);
                exerciseAdapter.notifyDataSetChanged();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {}
        });
    }

    private void setDayButtonColor(View dayView, int day) {
        CardView cardView = (CardView) dayView;
        TextView dayNumber = dayView.findViewById(R.id.dayNumber); // Acessar o TextView do número do dia

        if (isDayCompleted(day)) {
            cardView.setCardBackgroundColor(ContextCompat.getColor(getContext(), android.R.color.white));
            dayNumber.setTextColor(ContextCompat.getColor(getContext(), android.R.color.black)); // Definir a cor do texto como preta
        } else {
            cardView.setCardBackgroundColor(ContextCompat.getColor(getContext(), android.R.color.darker_gray));
            dayNumber.setTextColor(ContextCompat.getColor(getContext(), android.R.color.white)); // Definir a cor do texto como branca
        }
    }


    private void updateDayButtonColors() {
        for (int i = 0; i < calendarGrid.getChildCount(); i++) {
            View dayView = calendarGrid.getChildAt(i);
            int day = (int) dayView.getTag();
            setDayButtonColor(dayView, day);
        }
    }
}
