package com.example.appdigitalmtjava;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class HomeFragment extends Fragment {

    private Button logoutButton;

    public HomeFragment() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // Receber as informações do usuário dos argumentos
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("appPreferences", getContext().MODE_PRIVATE);

        String userName = sharedPreferences.getString("userName", "Usuário");
        String userWeight = sharedPreferences.getString("userWeight", "N/A");
        String userWaist = sharedPreferences.getString("userWaist", "N/A");
        String userAge = sharedPreferences.getString("userAge", "N/A");
        String userGender = sharedPreferences.getString("userGender", "N/A");
        String waterIntake = sharedPreferences.getString("waterIntake", "N/A");

        TextView welcomeTextView = view.findViewById(R.id.welcomeTextView);
        welcomeTextView.setText("Bem-vindo, " + userName + "!");

        TextView userDetailsTextView = view.findViewById(R.id.userDetailsTextView);
        userDetailsTextView.setText("Peso: " + userWeight + " kg\n" +
                "Cintura: " + userWaist + " cm\n" +
                "Idade: " + userAge + " anos\n" +
                "Gênero: " + userGender + "\n" +
                "Água recomendada: " + waterIntake);

        logoutButton = view.findViewById(R.id.logoutButton);
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Voltar para a tela de login
                Intent intent = new Intent(getActivity(), MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                getActivity().finish();
            }
        });

        return view;
    }
}
