package com.example.appdigitalmtjava;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import java.util.ArrayList;
import java.util.List;

public class CategoryFragment extends Fragment {

    private GridView categoriesGridView;
    private List<Category> categoryList;

    public CategoryFragment() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_categories_fragment, container, false);

        categoriesGridView = view.findViewById(R.id.categoriesGridView);

        // Inicializar lista de categorias
        categoryList = new ArrayList<>();
        loadCategories();

        CategoryAdapter adapter = new CategoryAdapter(getContext(), categoryList);
        categoriesGridView.setAdapter(adapter);

        categoriesGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Category category = categoryList.get(position);

                // Navegar para o fragmento de lista de receitas
                RecipesFragment recipesFragment = new RecipesFragment();
                Bundle bundle = new Bundle();
                bundle.putString("CATEGORY_NAME", category.getName());
                recipesFragment.setArguments(bundle);

                FragmentManager fragmentManager = getParentFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.fragment_container, recipesFragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });

        return view;
    }

    private void loadCategories() {
        categoryList.add(new Category("Panquecas e leites", R.drawable.panqueca));
        categoryList.add(new Category("Sumos Verdes", R.drawable.sumoverde));
        categoryList.add(new Category("Chás", R.drawable.greentea));
        categoryList.add(new Category("Refeições", R.drawable.caril_de_graos));
        categoryList.add(new Category("Shots detox", R.drawable.shotdetox));
        categoryList.add(new Category("Marmitas", R.drawable.marmita));
    }
}
