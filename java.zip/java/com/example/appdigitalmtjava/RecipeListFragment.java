package com.example.appdigitalmtjava;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RecipeListFragment extends Fragment {

    private ListView recipeListView;
    private List<String> recipeList;
    private static final Map<String, List<String>> categoryRecipesMap = new HashMap<>();

    static {
        // Preencher com dados de receitas de exemplo
        categoryRecipesMap.put("Pequeno almoço", new ArrayList<String>() {{
            add("Omelete de Espinafre");
            add("Panqueca Integral");
            add("Smoothie de Banana");
        }});
        categoryRecipesMap.put("Sucos verdes", new ArrayList<String>() {{
            add("Suco Detox de Couve");
            add("Suco Verde com Gengibre");
            add("Suco de Pepino e Limão");
        }});
        categoryRecipesMap.put("Chás", new ArrayList<String>() {{
            add("Chá de Camomila");
            add("Chá Verde");
            add("Chá de Hibisco");
        }});
        categoryRecipesMap.put("Refeições", new ArrayList<String>() {{
            add("Arroz Integral com Legumes");
            add("Frango Grelhado");
            add("Salada de Quinoa");
        }});
        categoryRecipesMap.put("Shots detox", new ArrayList<String>() {{
            add("Shot de Limão com Gengibre");
            add("Shot de Vinagre de Maçã");
            add("Shot de Cúrcuma");
        }});
        categoryRecipesMap.put("Marmitas", new ArrayList<String>() {{
            add("Marmita de Frango com Batata Doce");
            add("Marmita Vegana");
            add("Marmita Low Carb");
        }});
    }

    public RecipeListFragment() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.recipe_list_fragment, container, false);

        recipeListView = view.findViewById(R.id.recipesRecyclerView);

        // Obter o nome da categoria a partir dos argumentos
        String categoryName = getArguments().getString("CATEGORY_NAME");
        recipeList = categoryRecipesMap.get(categoryName);

        if (recipeList == null) {
            recipeList = new ArrayList<>();
            Toast.makeText(getContext(), "Nenhuma receita encontrada para a categoria " + categoryName, Toast.LENGTH_SHORT).show();
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, recipeList);
        recipeListView.setAdapter(adapter);

        return view;
    }
}
