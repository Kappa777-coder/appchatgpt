package com.example.appdigitalmtjava;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RecipesFragment extends Fragment {

    private RecyclerView recipesRecyclerView;
    private RecipesAdapter recipesAdapter;
    private List<Recipe> recipeList;
    private static final Map<String, List<Recipe>> categoryRecipesMap = new HashMap<>();

    static {
        // Preencher com dados de receitas de exemplo
        List<Recipe> breakfastRecipes = new ArrayList<>();
        breakfastRecipes.add(new Recipe("Omelete de Espinafre", "Uma deliciosa omelete com espinafre fresco", R.drawable.breakfast, ""));
        breakfastRecipes.add(new Recipe("Panqueca Integral", "Panquecas feitas com farinha integral", R.drawable.breakfast, ""));
        breakfastRecipes.add(new Recipe("Smoothie de Banana", "Smoothie refrescante com banana e aveia", R.drawable.breakfast, ""));
        categoryRecipesMap.put("Pequeno almoço", breakfastRecipes);

        List<Recipe> greenJuicesRecipes = new ArrayList<>();
        greenJuicesRecipes.add(new Recipe("Sumo detox 1", "Sumo detoxificante com couve", R.drawable.sucoverde, "Ingredientes:\n- 1 xícara (chá) de água\n- 2 folhas de couve verde\n- 1 pedaço pequeno de pepino\n- 1 maçã vermelha\n- Adicionar sumo de 1 lima batida com casca coado."));
        greenJuicesRecipes.add(new Recipe("Sumo detox 2", "Sumo verde com toque de gengibre", R.drawable.sucoverde, "Ingredientes:\n- 1 xícara (chá) de água\n- 2 folhas de couve verde\n- 1 rodela de abacaxi\n- 1 pedaço de gengibre qb."));
        greenJuicesRecipes.add(new Recipe("Sumo detox 3", "Refrescante sumo de pepino com limão", R.drawable.sucoverde, "Ingredientes:\n- 1 xícara (chá) de água\n- 1 folha de couve\n- 1 kiwi\n- ½ pepino\n- ½ colher de café de canela em pó\n- Adicionar sumo de 1 lima batida com casca coado."));
        greenJuicesRecipes.add(new Recipe("Sumo detox 4", "Sumo refrescante de espinafre e maçã", R.drawable.sucoverde, "Ingredientes:\n- 1 xícara (chá) de água\n- 1 mão de folhas de espinafres\n- 1 pedaço de gengibre\n- 1 pitada de canela\n- Adicionar sumo de 1 lima batida com casca coado."));
        greenJuicesRecipes.add(new Recipe("Sumo detox 5", "Sumo detox de aipo e abacaxi", R.drawable.sucoverde, "Ingredientes:\n- 1 xícara (chá) de água\n- 1 folha de couve\n- 1 mão cheia de frutos silvestres\n- 1 maçã\n- 1 colher de chá de sementes de chia."));
        greenJuicesRecipes.add(new Recipe("Sumo detox 6", "Sumo verde cremoso de couve e abacate", R.drawable.sucoverde, "Ingredientes:\n- 1 xícara (chá) de água\n- 2 folhas de couve\n- 2 caules de aipo picados\n- 1 maçã\n- Pedaços de gengibre fresco picado\n- 1 mão de mirtilos/framboesas\n- Adicionar sumo de 1 lima batida com casca coado."));
        greenJuicesRecipes.add(new Recipe("Sumo detox 7", "Sumo refrescante de hortelã e limão", R.drawable.sucoverde, "Ingredientes:\n- ½ Beterraba pequena\n- ½ Maçã verde\n- ½ Rodela de abacaxi\n- Sumo de ½ limão\n- 1 colher de sobremesa de sementes de linhaça\n- Hortelã qb."));
        greenJuicesRecipes.add(new Recipe("Sumo detox 8", "Sumo leve de alface e pepino", R.drawable.sucoverde, "Ingredientes:\n- 1 xícara (chá) de água\n- 1 talo de aipo\n- 2 chávenas de folhas de espinafre\n- ½ abacate\n- ½ maçã\n- Adicionar sumo de 1 lima batida com casca coado."));
        categoryRecipesMap.put("Sumos Verdes", greenJuicesRecipes);

        List<Recipe> teaRecipes = new ArrayList<>();
        teaRecipes.add(new Recipe("Chá verde", "Benefícios antioxidantes e desintoxicantes", R.drawable.tea, ""));
        teaRecipes.add(new Recipe("Chá de hibisco", "Auxilia na perda de peso e controle da pressão arterial", R.drawable.tea, ""));
        teaRecipes.add(new Recipe("Chá de cavalinha", "Diurético natural, combate retenção de líquidos", R.drawable.tea, ""));
        teaRecipes.add(new Recipe("Chá de gengibre", "Estimula a digestão e acelera o metabolismo", R.drawable.tea, ""));
        teaRecipes.add(new Recipe("Chá de hortelã", "Calmante natural, auxilia na digestão", R.drawable.tea, ""));
        teaRecipes.add(new Recipe("Chá de capim-limão", "Calmante, ajuda no combate à insônia", R.drawable.tea, ""));
        teaRecipes.add(new Recipe("Chá de curcuma", "Anti-inflamatório natural", R.drawable.tea, ""));
        teaRecipes.add(new Recipe("Chá de alcaçuz", "Auxilia no tratamento de úlceras e gastrite", R.drawable.tea, ""));
        teaRecipes.add(new Recipe("Chá de salsinha", "Diurético, ajuda a eliminar toxinas", R.drawable.tea, ""));
        teaRecipes.add(new Recipe("Chá de cidreira", "Calmante natural, combate a ansiedade", R.drawable.tea, ""));
        teaRecipes.add(new Recipe("Chá de canela", "Acelera o metabolismo e combate inflamações", R.drawable.tea, ""));
        teaRecipes.add(new Recipe("Chá de anis", "Ajuda a combater gases e cólicas", R.drawable.tea, ""));
        teaRecipes.add(new Recipe("Chá de limonete", "Calmante e digestivo", R.drawable.tea, ""));
        teaRecipes.add(new Recipe("Chá de dente de leão", "Diurético e desintoxicante", R.drawable.tea, ""));
        categoryRecipesMap.put("Chás", teaRecipes);

        List<Recipe> mealRecipes = new ArrayList<>();
        mealRecipes.add(new Recipe("Arroz Integral com Legumes", "Arroz integral nutritivo com legumes", R.drawable.meals, ""));
        mealRecipes.add(new Recipe("Frango Grelhado", "Frango grelhado suculento", R.drawable.meals, ""));
        mealRecipes.add(new Recipe("Salada de Quinoa", "Salada saudável de quinoa", R.drawable.meals, ""));
        categoryRecipesMap.put("Refeições", mealRecipes);

        List<Recipe> detoxShotsRecipes = new ArrayList<>();
        detoxShotsRecipes.add(new Recipe("Shot de Limão com Gengibre", "Shot energizante de limão e gengibre", R.drawable.tea, ""));
        detoxShotsRecipes.add(new Recipe("Shot de Vinagre de Maçã", "Shot detox de vinagre de maçã", R.drawable.tea, ""));
        detoxShotsRecipes.add(new Recipe("Shot de Cúrcuma", "Shot anti-inflamatório de cúrcuma", R.drawable.tea, ""));
        categoryRecipesMap.put("Shots detox", detoxShotsRecipes);

        List<Recipe> mealPrepRecipes = new ArrayList<>();
        mealPrepRecipes.add(new Recipe("Marmita 1", "Descrição da Marmita 1", R.drawable.meal_prep, "Base: Arroz integral bio (+-100g), Feijão azuki (+-60g)", "Recheio: Brócolos, Cenoura, Pepino, Rabanete, Abacate", "Tempero: Limão, Azeite, Sal integral, Sementes de sésamo"));
        mealPrepRecipes.add(new Recipe("Marmita 2", "Descrição da Marmita 2", R.drawable.meal_prep, "Base: Quinoa real bio (+-100g), Lentilhas verdes (+-60g)", "Recheio: Agrião, Tomate, Curgete, Abóbora, Fruta da época", "Tempero: Limão, Azeite, Sal integral, Sementes de chia"));
        mealPrepRecipes.add(new Recipe("Marmita 3", "Descrição da Marmita 3", R.drawable.meal_prep, "Base: Arroz integral bio (+-100g), Grão de bico (+-60g)", "Recheio: Alface, Beterraba, Couve roxa, Cenoura, Fruta da época", "Tempero: Limão, Azeite, Sal integral, Sementes de abóbora"));
        mealPrepRecipes.add(new Recipe("Marmita 4", "Descrição da Marmita 4", R.drawable.meal_prep, "Base: Cevada bio (+-100g), Feijão preto (+-60g)", "Recheio: Espinafres, Tomate cherry, Cenoura, Rabanete, Pepino", "Tempero: Limão, Azeite, Sal integral, Sementes de girassol"));
        mealPrepRecipes.add(new Recipe("Marmita 5", "Descrição da Marmita 5", R.drawable.meal_prep, "Base: Arroz integral bio (+-100g), Feijão frade (+-60g)", "Recheio: Alface, Tomate, Cenoura, Courgette, Fruta da época", "Tempero: Limão, Azeite, Sal integral, Sementes de girassol"));
        mealPrepRecipes.add(new Recipe("Marmita 6", "Descrição da Marmita 6", R.drawable.meal_prep, "Base: Quinoa real bio (+-100g), Lentilhas castanhas (+-60g)", "Recheio: Agrião, Cenoura, Couve roxa, Fruta da época, Abacate", "Tempero: Limão, Azeite, Sal integral, Sementes de abóbora"));
        mealPrepRecipes.add(new Recipe("Marmita 7", "Descrição da Marmita 7", R.drawable.meal_prep, "Base: Arroz integral bio (+-100g), Feijão branco (+-60g)", "Recheio: Agrião, Pepino, Rabanete, Cenoura, Tomate", "Tempero: Limão, Azeite, Sal integral, Sementes de girassol"));
        mealPrepRecipes.add(new Recipe("Marmita 8", "Descrição da Marmita 8", R.drawable.meal_prep, "Base: Arroz integral bio (+-100g), Grão de bico (+-60g)", "Recheio: Alface, Beterraba, Cenoura, Fruta da época, Abacate", "Tempero: Limão, Azeite, Sal integral, Sementes de chia"));
        mealPrepRecipes.add(new Recipe("Marmita 9", "Descrição da Marmita 9", R.drawable.meal_prep, "Base: Arroz integral bio (+-100g), Feijão mungo (+-60g)", "Recheio: Alface, Cenoura, Pepino, Rabanete, Fruta da época", "Tempero: Limão, Azeite, Sal integral, Sementes de sésamo"));
        mealPrepRecipes.add(new Recipe("Marmita 10", "Descrição da Marmita 10", R.drawable.meal_prep, "Base: Cevada bio (+-100g), Feijão vermelho (+-60g)", "Recheio: Agrião, Tomate cherry, Couve roxa, Abacate, Fruta da época", "Tempero: Limão, Azeite, Sal integral, Sementes de girassol"));
        mealPrepRecipes.add(new Recipe("Marmita 11", "Descrição da Marmita 11", R.drawable.meal_prep, "Base: Quinoa real bio (+-100g), Lentilhas pretas (+-60g)", "Recheio: Alface, Tomate cherry, Cenoura, Fruta da época, Abacate", "Tempero: Limão, Azeite, Sal integral, Sementes de chia"));
        mealPrepRecipes.add(new Recipe("Marmita 12", "Descrição da Marmita 12", R.drawable.meal_prep, "Base: Arroz integral bio (+-100g), Grão de bico (+-60g)", "Recheio: Beterraba, Pepino, Alface, Tangerina, Flocos de coco", "Tempero: Limão, Azeite, Sal integral, Sementes mix"));
        mealPrepRecipes.add(new Recipe("Marmita 13", "Descrição da Marmita 13", R.drawable.meal_prep, "Base: Arroz integral bio (+-100g), Lentilha (+-60g)", "Recheio: Abóbora, Curgete, Cogumelos, Espinafres, Cenoura, Couve-flor salteados", "Tempero: Limão, Azeite, Sal integral, Sementes"));
        mealPrepRecipes.add(new Recipe("Marmita 14", "Descrição da Marmita 14", R.drawable.meal_prep, "Base: Arroz integral bio (+-100g), Grão (+-60g)", "Recheio: Ovo cozido, Pimentos a gosto, Tomate cherry, Cebola roxa, Beterraba, Couve roxa", "Tempero: Salsa, Limão, Azeite, Sal integral, Sementes"));
        mealPrepRecipes.add(new Recipe("Marmita 15", "Descrição da Marmita 15", R.drawable.meal_prep, "Base: Arroz integral bio (+-100g), Feijão mungo (+-60g)", "Recheio: Agrião, Tangerina, Azeitona, Abacate, Manga", "Tempero: Limão, Azeite, Sal integral, Sementes"));
        categoryRecipesMap.put("Marmitas", mealPrepRecipes);
    }

    public RecipesFragment() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.recipe_list_fragment, container, false);

        recipesRecyclerView = view.findViewById(R.id.recipesRecyclerView);
        recipesRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Obter o nome da categoria a partir dos argumentos
        String categoryName = getArguments().getString("CATEGORY_NAME");
        recipeList = categoryRecipesMap.get(categoryName);

        if (recipeList == null) {
            recipeList = new ArrayList<>();
            Toast.makeText(getContext(), "Nenhuma receita encontrada para a categoria " + categoryName, Toast.LENGTH_SHORT).show();
        }

        recipesAdapter = new RecipesAdapter(recipeList);
        recipesRecyclerView.setAdapter(recipesAdapter);

        return view;
    }
}
