package com.example.appdigitalmtjava;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.home_activity);

        // Receber o nome do usuário do Intent
        String userName = getIntent().getStringExtra("USER_NAME");

        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setOnNavigationItemSelectedListener(navListener);

        // Set default fragment and pass the user name
        if (savedInstanceState == null) {
            HomeFragment homeFragment = new HomeFragment();
            Bundle bundle = new Bundle();
            bundle.putString("USER_NAME", userName);
            homeFragment.setArguments(bundle);
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, homeFragment).commit();
        }

        // Handle back button press
        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                // Mostrar mensagem ou simplesmente não fazer nada
                Toast.makeText(HomeActivity.this, "Você já está na tela inicial", Toast.LENGTH_SHORT).show();
            }
        };
        this.getOnBackPressedDispatcher().addCallback(this, callback);
    }

    private final BottomNavigationView.OnNavigationItemSelectedListener navListener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    Fragment selectedFragment = null;

                    if (item.getItemId() == R.id.nav_home) {
                        selectedFragment = new HomeFragment();
                    } else if (item.getItemId() == R.id.nav_treino) {
                        selectedFragment = new TreinoFragment();
                    } else if (item.getItemId() == R.id.nav_recipe) {
                        selectedFragment = new CategoryFragment();
                    }

                    if (selectedFragment != null) {
                        // Pass the user name to the selected fragment if it's HomeFragment
                        if (selectedFragment instanceof HomeFragment) {
                            String userName = getIntent().getStringExtra("USER_NAME");
                            Bundle bundle = new Bundle();
                            bundle.putString("USER_NAME", userName);
                            selectedFragment.setArguments(bundle);
                        }
                        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, selectedFragment).commit();
                    }

                    return true;
                }
            };
}
