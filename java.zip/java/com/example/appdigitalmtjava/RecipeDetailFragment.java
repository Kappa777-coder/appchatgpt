package com.example.appdigitalmtjava;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class RecipeDetailFragment extends Fragment {

    private ImageView recipeImageView;
    private TextView recipeTitleTextView;
    private TextView recipeIngredientsTextView;
    private TextView recipeBaseTextView;
    private TextView recipeRecheioTextView;
    private TextView recipeTemperoTextView;

    public RecipeDetailFragment() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_recipe_detail, container, false);

        recipeImageView = view.findViewById(R.id.recipeImage);
        recipeTitleTextView = view.findViewById(R.id.recipeTitle);
        recipeIngredientsTextView = view.findViewById(R.id.recipeIngredients);
        recipeBaseTextView = view.findViewById(R.id.recipeBase);
        recipeRecheioTextView = view.findViewById(R.id.recipeRecheio);
        recipeTemperoTextView = view.findViewById(R.id.recipeTempero);

        Bundle bundle = getArguments();
        if (bundle != null) {
            recipeImageView.setImageResource(bundle.getInt("IMAGE_RES_ID"));
            recipeTitleTextView.setText(bundle.getString("TITLE"));

            String ingredients = bundle.getString("INGREDIENTS");
            if (ingredients != null) {
                recipeIngredientsTextView.setText(ingredients);
                recipeIngredientsTextView.setVisibility(View.VISIBLE);
                recipeBaseTextView.setVisibility(View.GONE);
                recipeRecheioTextView.setVisibility(View.GONE);
                recipeTemperoTextView.setVisibility(View.GONE);
            } else {
                recipeBaseTextView.setText("Base: " + bundle.getString("BASE"));
                recipeRecheioTextView.setText("Recheio: " + bundle.getString("RECHEIO"));
                recipeTemperoTextView.setText("Tempero: " + bundle.getString("TEMPERO"));
                recipeIngredientsTextView.setVisibility(View.GONE);
                recipeBaseTextView.setVisibility(View.VISIBLE);
                recipeRecheioTextView.setVisibility(View.VISIBLE);
                recipeTemperoTextView.setVisibility(View.VISIBLE);
            }
        }

        return view;
    }
}
