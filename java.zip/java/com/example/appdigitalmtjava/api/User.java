package com.example.appdigitalmtjava.api;

public class User {
    private String name;
    private float weight;
    private float waist;
    private int age;
    private String gender;
    private float waterIntake;

    public User(String name, float weight, float waist, int age, String gender, float waterIntake) {
        this.name = name;
        this.weight = weight;
        this.waist = waist;
        this.age = age;
        this.gender = gender;
        this.waterIntake = waterIntake;
    }

    // Getters and setters (or you can use Lombok to generate them)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getWeight() {
        return weight;
    }

    public void setWeight(float weight) {
        this.weight = weight;
    }

    public float getWaist() {
        return waist;
    }

    public void setWaist(float waist) {
        this.waist = waist;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public float getWaterIntake() {
        return waterIntake;
    }

    public void setWaterIntake(float waterIntake) {
        this.waterIntake = waterIntake;
    }
}
